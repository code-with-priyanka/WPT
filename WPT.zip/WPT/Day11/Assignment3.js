 const http =new require('http');
let a=10;
function creatingserver1()
{
   
console.log(a);
    if(http)
    {
        console.log("We are created a server");
    }
    
    const server =http.createServer(function(req,res){

        res.writeHead(200,{'contenttype':'text/plain'});
        res.end("Hello from Atul Server");
    });
    server.listen(8080);
}
creatingserver1()