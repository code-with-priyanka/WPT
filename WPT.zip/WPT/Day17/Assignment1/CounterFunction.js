import React, { useState, useEffect } from 'react';

export function CounterFunction() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    console.log('Component mounted');

    return () => {
      console.log(' Component unmounted');
    };
  }, []);


  useEffect(() => {
    console.log(' Component updated');
  });

 

  return (
    <div>
      <h2>React useEffect functional component</h2>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
    </div>
  );
}

