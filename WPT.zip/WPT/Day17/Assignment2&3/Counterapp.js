import React, { useState } from 'react';

function CounterApp() {
  const [count, setCount] = useState(0);
//Using useState
  return (
    <div>
      <h2>Counter using useState: {count}</h2>
      <button onClick={() => setCount(count + 1)}>click me</button>
    </div>
  );
}

export default CounterApp;
