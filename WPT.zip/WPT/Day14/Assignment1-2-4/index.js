const express = require('express');
const app = express();
const f = require('fs');
const users1 = require('./MOCK_DATA.json');
const p = require('path');
const port = 4040;
exports.app = app;



app.get('/users', (req, res) => {
    return res.json(users1);
});


app.get('/users/:id', (req, res) => {
    const id = Number(req.params.id);
    const user = users1.find(user => user.id === id);
    if (!user) {
        return res.status(404).send('User not found');
    }
    return res.json(user);
});

app.post('/user/:id', (req, res) => {
    const id = Number(req.params.id);  
    
    const user = users1.find(
        user => user.id === id
    )
    
    return res.json(user);

});

app.delete('/user/:id', (req, res) => {
    const id = Number(req.params.id); 
    
    const userIndex = users1.findIndex(
        user => user.id === id
    )
    if (userIndex === -1)
        return res.status(404).send('Data not found');

    const deletedItem = users1.splice(userIndex, 1);
    return res.json("HOLA AMIGOS WE FOUND THAT! ");
});

app.use(express.urlencoded({ extended: false }))
app.post('/adduser',(req,res) => {     // adding any record 
    const data = req.body;
     console.log("data " + data.email);
    users1.push(
        { data, id: users1.length + 1 });
    f.writeFile('./MOCK_DATA.json',
        JSON.stringify(users1), (err) => {
            console.log(err)
        });

    return res.json("Data Added Sucesfully ");

});

app.get('/aboutus', (req, res) => {
    const t = p.join(__dirname, 'aboutus.html');
    console.log(t);
    res.sendFile(t);      //about us msg to console 
});



app.listen(port, () => {
    console.log("server started :" + `http://localhost:${port}/`);
})

